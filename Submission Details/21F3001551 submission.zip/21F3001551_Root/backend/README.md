# Backend Installation


### Create a New virtual environment

```
python3 -m venv .venv
```

### Activate the virtual environment

```
source .venv/bin/activate 
```

### Install all the depedenices

```
pip install -r requirements.txt
```

### Start Redis Server

```
redis-server
```

### Run the app

```
python app.py
```
